/* ================================================================
   EXPORT.JS
   PNG download and file-to-image loading helpers.
   No rendering logic here — this only moves bytes in and out of
   the canvas, so it can be reused by any future export format
   (e.g. a "copy to clipboard" button) without touching the renderer.
   ================================================================ */

/**
 * Triggers a browser download of the canvas as a PNG file.
 * @param {HTMLCanvasElement} canvas
 * @param {string} filename
 */
function dsDownloadCanvasAsPng(canvas, filename = "dark-souls-text.png") {
  canvas.toBlob(blob => {
    if (!blob) {
      console.error("dsDownloadCanvasAsPng: canvas.toBlob returned null");
      return;
    }
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }, "image/png");
}

/**
 * Reads a user-selected file input and resolves with a loaded
 * HTMLImageElement, or rejects if the file isn't a readable image.
 * @param {File} file
 * @returns {Promise<HTMLImageElement>}
 */
function dsLoadImageFromFile(file) {
  return new Promise((resolve, reject) => {
    if (!file || !file.type.startsWith("image/")) {
      reject(new Error("Selected file is not an image"));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error("Could not decode image file"));
      img.src = reader.result;
    };
    reader.onerror = () => reject(new Error("Could not read file"));
    reader.readAsDataURL(file);
  });
}

/**
 * Resizes the canvas element to match a background image's aspect
 * ratio (e.g. for portrait mobile wallpaper exports), capping the
 * longest side at maxDimension so exports stay a reasonable file size.
 * @param {HTMLCanvasElement} canvas
 * @param {HTMLImageElement} image
 * @param {number} maxDimension
 */
function dsFitCanvasToImage(canvas, image, maxDimension = 1400) {
  const ratio = image.width / image.height;
  if (ratio >= 1) {
    canvas.width = maxDimension;
    canvas.height = Math.round(maxDimension / ratio);
  } else {
    canvas.height = maxDimension;
    canvas.width = Math.round(maxDimension * ratio);
  }
}
