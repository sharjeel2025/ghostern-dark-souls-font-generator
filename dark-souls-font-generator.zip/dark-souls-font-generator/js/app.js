/* ================================================================
   APP.JS
   Wires up UI controls to the pure functions in canvas-renderer.js
   and export.js. This is the only file that touches the DOM directly.
   ================================================================ */

(function () {
  "use strict";

  const canvas = document.getElementById("ds-canvas");

  const els = {
    mainText: document.getElementById("ds-main-text"),
    subText: document.getElementById("ds-sub-text"),
    font: document.getElementById("ds-font"),
    colorPreset: document.getElementById("ds-color-preset"),
    customColorWrap: document.getElementById("ds-custom-color-wrap"),
    customColor: document.getElementById("ds-custom-color"),
    glowBlur: document.getElementById("ds-glow-blur"),
    glowBlurVal: document.getElementById("ds-glow-blur-val"),
    fontSize: document.getElementById("ds-font-size"),
    fontSizeVal: document.getElementById("ds-font-size-val"),
    transparentBg: document.getElementById("ds-transparent-bg"),
    bgUpload: document.getElementById("ds-bg-upload"),
    fitCanvasBtn: document.getElementById("ds-fit-canvas"),
    downloadBtn: document.getElementById("ds-download"),
    presetsWrap: document.getElementById("ds-presets")
  };

  /** @type {HTMLImageElement|null} */
  let bgImage = null;

  /**
   * Reads all current control values into a render state object.
   * @returns {DsRenderState}
   */
  function getState() {
    const usingCustom = els.colorPreset.value === "custom";
    return {
      mainText: els.mainText.value || " ",
      subText: els.subText.value,
      fontFamily: els.font.value,
      glowColor: usingCustom ? els.customColor.value : els.colorPreset.value,
      glowBlur: Number(els.glowBlur.value),
      fontSize: Number(els.fontSize.value),
      transparentBg: els.transparentBg.checked,
      bgImage: bgImage
    };
  }

  /** Re-renders the canvas from current control state. */
  function render() {
    dsRenderScene(canvas, getState());
  }

  /** Applies a text preset by name and re-renders. */
  function applyPreset(name) {
    els.mainText.value = name;
    els.subText.value = DS_TEXT_PRESETS[name] || "";
    [...els.presetsWrap.children].forEach(btn => {
      btn.classList.toggle("active", btn.dataset.preset === name);
    });
    render();
  }

  // ── Event wiring ──

  els.presetsWrap.addEventListener("click", e => {
    const btn = e.target.closest("button[data-preset]");
    if (btn) applyPreset(btn.dataset.preset);
  });

  els.mainText.addEventListener("input", render);
  els.subText.addEventListener("input", render);

  els.font.addEventListener("change", () => {
    const family = els.font.value.replace(/'/g, "").split(",")[0];
    dsWaitForFonts([family]).then(render);
  });

  els.colorPreset.addEventListener("change", () => {
    els.customColorWrap.hidden = els.colorPreset.value !== "custom";
    render();
  });
  els.customColor.addEventListener("input", render);

  els.glowBlur.addEventListener("input", () => {
    els.glowBlurVal.textContent = els.glowBlur.value;
    render();
  });

  els.fontSize.addEventListener("input", () => {
    els.fontSizeVal.textContent = els.fontSize.value;
    render();
  });

  els.transparentBg.addEventListener("change", render);

  els.bgUpload.addEventListener("change", async () => {
    const file = els.bgUpload.files[0];
    if (!file) return;
    try {
      bgImage = await dsLoadImageFromFile(file);
      render();
    } catch (err) {
      console.error(err);
      alert("Couldn't load that image — please try a different file.");
    }
  });

  els.fitCanvasBtn.addEventListener("click", () => {
    if (!bgImage) {
      alert("Upload a background image first, then fit the canvas to it.");
      return;
    }
    dsFitCanvasToImage(canvas, bgImage);
    render();
  });

  els.downloadBtn.addEventListener("click", () => {
    const filename = (els.mainText.value.trim() || "dark-souls-text")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "") + ".png";
    dsDownloadCanvasAsPng(canvas, filename);
  });

  // ── Initial render, once web fonts are ready ──
  dsWaitForFonts(["Cinzel"]).then(render);
})();
