/* ================================================================
   FONTS.JS
   Font list and color/glow presets used by the renderer.
   Kept separate from rendering logic so presets can be extended
   without touching canvas code.
   ================================================================ */

const DS_GLOW_PRESETS = {
  "#ff1a1a": "Blood",
  "#e68a2e": "Ember",
  "#c5a059": "Gold",
  "#8db4d8": "Frost",
  "#1a1a2e": "Abyss"
};

// Text presets mapped to a sensible default subtitle.
// Empty string means "no subtitle by default" for that preset.
const DS_TEXT_PRESETS = {
  "YOU DIED": "",
  "VICTORY ACHIEVED": "",
  "BONFIRE LIT": "",
  "HOLLOW": "",
  "PREY SLAUGHTERED": "",
  "YOU DEFEATED": ""
};

/**
 * Waits for the given font families to finish loading (Google Fonts
 * are loaded via <link> in index.html, but the browser may not have
 * rasterized glyphs yet on first paint). Falls back gracefully if the
 * Font Loading API isn't available.
 * @param {string[]} families
 * @returns {Promise<void>}
 */
function dsWaitForFonts(families) {
  if (!document.fonts || !document.fonts.load) {
    return Promise.resolve();
  }
  const loads = families.map(family =>
    document.fonts.load(`900 90px ${family}`).catch(() => {})
  );
  return Promise.all(loads).then(() => document.fonts.ready).catch(() => {});
}
