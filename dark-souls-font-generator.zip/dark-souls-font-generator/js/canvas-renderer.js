/* ================================================================
   CANVAS-RENDERER.JS
   Pure rendering functions. No DOM event listeners here — this file
   only knows how to draw a given state onto a canvas. Wiring lives
   in app.js so the renderer can be reused/tested independently.
   ================================================================ */

const DS_CANVAS_WIDTH = 1200;
const DS_CANVAS_HEIGHT = 600;

/**
 * @typedef {Object} DsRenderState
 * @property {string} mainText
 * @property {string} subText
 * @property {string} fontFamily     - CSS font-family string, e.g. "'Cinzel', serif"
 * @property {string} glowColor      - hex color, e.g. "#c5a059"
 * @property {number} glowBlur       - 0-34
 * @property {number} fontSize       - px, main text size (subtitle is derived from this)
 * @property {boolean} transparentBg
 * @property {HTMLImageElement|null} bgImage
 */

/**
 * Draws the full scene (background + glow text) onto the given canvas.
 * @param {HTMLCanvasElement} canvas
 * @param {DsRenderState} state
 */
function dsRenderScene(canvas, state) {
  const ctx = canvas.getContext("2d");
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  dsDrawBackground(ctx, canvas, state);
  dsDrawGlowText(ctx, canvas, state);
}

/**
 * Fills the background: transparent, solid black, or a user-supplied image.
 * Image is drawn "cover" style so it always fills the canvas without
 * distortion, matching the aspect-fit behavior used by the "fit canvas
 * to background" control in app.js.
 */
function dsDrawBackground(ctx, canvas, state) {
  const { transparentBg, bgImage } = state;

  if (transparentBg && !bgImage) {
    // Leave fully transparent — do nothing, PNG export will preserve alpha.
    return;
  }

  if (bgImage) {
    const canvasRatio = canvas.width / canvas.height;
    const imgRatio = bgImage.width / bgImage.height;
    let drawWidth, drawHeight, offsetX, offsetY;

    if (imgRatio > canvasRatio) {
      // Image is wider than canvas — fit height, crop sides
      drawHeight = canvas.height;
      drawWidth = drawHeight * imgRatio;
      offsetX = (canvas.width - drawWidth) / 2;
      offsetY = 0;
    } else {
      // Image is taller than canvas — fit width, crop top/bottom
      drawWidth = canvas.width;
      drawHeight = drawWidth / imgRatio;
      offsetX = 0;
      offsetY = (canvas.height - drawHeight) / 2;
    }

    ctx.drawImage(bgImage, offsetX, offsetY, drawWidth, drawHeight);

    // Slight dark overlay so text stays legible over busy backgrounds
    ctx.fillStyle = "rgba(0, 0, 0, 0.35)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    return;
  }

  // Default: solid black, matching the in-game death screen background
  ctx.fillStyle = "#000000";
  ctx.fillRect(0, 0, canvas.width, canvas.height);
}

/**
 * Draws the main text and optional subtitle with a layered glow effect.
 *
 * The glow is built from multiple shadowBlur passes on the *same* canvas
 * context rather than a CSS filter, because CSS filters are not captured
 * by canvas.toDataURL()/toBlob() in all browsers — this keeps the glow
 * visible in the exported PNG, not just the on-screen preview.
 */
function dsDrawGlowText(ctx, canvas, state) {
  const { mainText, subText, fontFamily, glowColor, glowBlur, fontSize } = state;

  const centerX = canvas.width / 2;
  const centerY = subText ? canvas.height / 2 - fontSize * 0.2 : canvas.height / 2;

  ctx.textAlign = "center";
  ctx.textBaseline = "middle";

  // ── Layered glow passes (soft outer glow, tighter inner glow) ──
  const passes = [
    { blur: glowBlur * 1.6, alpha: 0.35 },
    { blur: glowBlur,       alpha: 0.55 },
    { blur: glowBlur * 0.5, alpha: 0.85 }
  ];

  ctx.font = `900 ${fontSize}px ${fontFamily}`;

  passes.forEach(pass => {
    ctx.save();
    ctx.shadowColor = glowColor;
    ctx.shadowBlur = pass.blur;
    ctx.fillStyle = `rgba(255, 255, 255, ${pass.alpha})`;
    ctx.fillText(mainText.toUpperCase(), centerX, centerY);
    ctx.restore();
  });

  // ── Crisp top layer so text stays readable, not just a glow blob ──
  ctx.save();
  ctx.shadowColor = glowColor;
  ctx.shadowBlur = glowBlur * 0.3;
  ctx.fillStyle = "#f5f0e6";
  ctx.fillText(mainText.toUpperCase(), centerX, centerY);
  ctx.restore();

  // ── Subtitle, smaller and slightly below the main text ──
  if (subText) {
    const subSize = Math.max(18, fontSize * 0.32);
    const subY = centerY + fontSize * 0.75;

    ctx.font = `600 ${subSize}px ${fontFamily}`;
    ctx.save();
    ctx.shadowColor = glowColor;
    ctx.shadowBlur = glowBlur * 0.4;
    ctx.fillStyle = "rgba(245, 240, 230, 0.9)";
    ctx.fillText(subText.toUpperCase(), centerX, subY);
    ctx.restore();
  }
}
